#!/bin/bash

sudo apt install python3-pip -y
pip3 install z3-solver
