# Instrumentation variables
problem_size = 0

z3_calls = 0
interpolants_generated = 0
merges = 0
shiftdowns = 0
offsets = 0

reduction_time = 0
augment_time = 0
interpolation_time = 0
solution_time = 0
